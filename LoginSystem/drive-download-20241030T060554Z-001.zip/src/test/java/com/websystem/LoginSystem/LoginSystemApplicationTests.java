package com.websystem.LoginSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
