package com.websystem.LoginSystem.models;

public enum BoardType {
    CBSE, UPBOARD, ISCS
}