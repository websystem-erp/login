package com.websystem.LoginSystem.Services;

public class CollegeEmployeeServices {
}
