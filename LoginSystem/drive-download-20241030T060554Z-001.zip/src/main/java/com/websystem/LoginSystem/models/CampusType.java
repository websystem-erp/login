package com.websystem.LoginSystem.models;

public enum CampusType {
    SCHOOL, COLLEGE
}